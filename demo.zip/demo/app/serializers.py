from rest_framework import serializers
from .models import *

class LoginSerializer(serializers.Serializer):
    password = serializers.CharField()
    user_login = serializers.CharField()


class RegistrationSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['fio', 'email', 'phone', 'user_login', 'password']

    def save(self, **kwargs):
        user = User(
            fio = self.validated_data['fio'],
            email = self.validated_data['email'],
            phone = self.validated_data['phone'],
            user_login = self.validated_data['user_login'],
            username = self.validated_data['user_login'],
        )
        user.set_password(self.validated_data['password'])
        user.save()
        return user


class ApplicationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Application
        fields = '__all__'


class ApplicationCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Application
        fields = ['name', 'auto_number', 'description']