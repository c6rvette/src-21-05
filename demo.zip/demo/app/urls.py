from django.urls import path
from .views import *

urlpatterns = [
    path('login/', login),
    path('signup/', registration),
    path('logout/', logout),
    path('application/<int:pk>', changeApplicationClient),
    path('application/', createApplication),
    path('applications', getApplicationsAll),
    path('admin/', getApplicationsAll),
    path('admin/<int:pk>', changeApplicationAdmin)
]