from .models import *
from .serializers import *
from .permissions import IsClient
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated, IsAdminUser

@api_view(['POST'])
def login(request):
    login_serializer = LoginSerializer(data=request.data)
    if login_serializer.is_valid():
        try:
            user = User.objects.get(user_login=login_serializer.validated_data['user_login'])
        except:
            return Response({'error': {'code': 401, 'message': 'Authentication failed'}}, status=401)
        if not user.check_password(raw_password=login_serializer.validated_data['password']):
            return Response({'error': {'code': 401, 'message': 'Authentication failed'}}, status=401)
        token, _ = Token.objects.get_or_create(user=user)
        return Response({'data': {'user_token': token.key, 'isAdmin': user.is_staff}}, status=200)
    return Response({'error': {'code': 422, 'message': 'Validation error', 'errors': login_serializer.errors}}, status=422)

@api_view(['POST'])
def registration(request):
    registration_serializer = RegistrationSerializer(data=request.data)
    if registration_serializer.is_valid():
        user = registration_serializer.save()
        token = Token.objects.create(user=user)
        return Response({'data': {'user_token': token.key, 'isAdmin': user.is_staff}})
    return Response({'error': {'code': 422, 'message': 'Validation error', 'errors': registration_serializer.errors}}, status=422)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def logout(request):
    request.user.auth_token.delete()
    return Response({'data': {'message': 'logout'}}, status=200)



@api_view(['GET'])
def getApplicationsAll(request):
    if request.user.is_authenticated and not request.user.is_staff:
        applications = Application.objects.filter(user=request.user)
    elif not request.user.is_authenticated or request.user.is_staff:
        applications = Application.objects.all()
    applications_list = []
    for application in applications:
        applications_list.append({
            'id': application.id,
            'name': application.name,
            'auto_number': application.auto_number,
            'description': application.description,
            'fio': application.user.fio,
            'status': application.status.name
        })
    return Response({'data': applications_list}, status=200)


@api_view(['POST'])
@permission_classes([IsClient])
def createApplication(request):
    application_serializer = ApplicationCreateSerializer(data=request.data)
    if application_serializer.is_valid():
        status = Status.objects.get(name='new')
        application = Application.objects.create(
            name = application_serializer.validated_data['name'],
            auto_number = application_serializer.validated_data['auto_number'],
            description = application_serializer.validated_data['description'],
            user = request.user,
            status = status
        )
        application.save()
        return Response({'data': {'message': 'App was added'}}, status=201)
    return Response({'error': {'code': 422, 'message': 'Validation error', 'errors': application_serializer.errors}}, status=422)


@api_view(['DELETE', 'PATCH', 'GET'])
@permission_classes([IsClient])
def changeApplicationClient(request,pk):
    try:
        application = Application.objects.get(pk=pk)
    except:
        return Response({'error': {'code': 404, 'message': 'Application not found'}}, status=404)
    if not application.user == request.user:
        return Response({'error': {'code': 403, 'message': 'Forbidden for you'}}, status=403)
    if request.method == 'DELETE':
        application.delete()
        return Response({'data': {'message': 'Application deleted'}}, status=200)
    elif request.method == 'PATCH':
        application_serializer = ApplicationCreateSerializer(data=request.data, instance=application, partial=True)
        if application_serializer.is_valid():
            application = application_serializer.save()
            return Response({'data': {
                'id': application.id,
                'name': application.name,
                'auto_number': application.auto_number,
                'description': application.description,
                'fio': application.user.fio,
                'status': application.status.name
            }}, status=200)
        return Response(
            {'error': {'code': 422, 'message': 'Validation error', 'errors': application_serializer.errors}},
            status=422)
    elif request.method == 'GET':
        return Response({'data': {
            'id': application.id,
            'name': application.name,
            'auto_number': application.auto_number,
            'description': application.description,
            'fio': application.user.fio,
            'status': application.status.name
        }})


@api_view(['PATCH', 'DELETE'])
@permission_classes([IsAdminUser])
def changeApplicationAdmin(request,pk):
    try:
        application = Application.objects.get(pk=pk)
    except:
        return Response({'error': {'code': 404, 'message': 'Not found'}}, status=404)
    if request.method == 'DELETE':
        application.delete()
        return Response({'data': {'message': 'Application deleted'}}, status=200)
    elif request.method == 'PATCH':
        try:
            status = Status.objects.get(name = request.data['status']).id
        except:
            return Response({'error': {'code': 404, 'message': 'Not found'}}, status=404)
        application_serializer = ApplicationSerializer(data={'status': status}, instance=application, partial=True)
        if application_serializer.is_valid():
            application = application_serializer.save()
            return Response({'data': {
                'id': application.id,
                'name': application.name,
                'auto_number': application.auto_number,
                'description': application.description,
                'fio': application.user.fio,
                'status': application.status.name
            }}, status=200)
        return Response(
            {'error': {'code': 422, 'message': 'Validation error', 'errors': application_serializer.errors}},
            status=422)
