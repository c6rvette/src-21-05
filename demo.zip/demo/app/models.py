from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.validators import MinLengthValidator

class User(AbstractUser):
    fio = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=12)
    user_login = models.CharField(max_length=50, unique=True)
    password = models.CharField(max_length=50, validators=[MinLengthValidator(6)])

    USERNAME_FIELD = 'user_login'
    REQUIRED_FIELDS = ['username', 'fio', 'email', 'phone', 'password']


class Status(models.Model):
    name = models.CharField(max_length=20)

    def __str__(self):
        return f'{self.name}'


class Application(models.Model):
    name = models.CharField(max_length=100)
    auto_number = models.CharField(max_length=6)
    description = models.TextField(max_length=500)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    status = models.ForeignKey(Status, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.auto_number}'

