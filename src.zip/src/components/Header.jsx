import { useNavigate } from 'react-router-dom'
import '../assets/css/style.css'
import logo from '../assets/img/car3.png'
import { Link } from 'react-router-dom'

export default function Header({isAdmin, userToken, setIsAdmin, setUserToken}) {
    const navigate = useNavigate()

    function logout(event) {
        event.preventDefault()
        fetch('http://127.0.0.1:8000/api-copp/logout', {
            method: 'GET',
            headers: {
                'Content-type': 'application/json',
                'Authorization': `Bearer ${userToken}`
            }
        })
        .then(() => {
            setUserToken('')
            setIsAdmin('')
            navigate('/')
        })
    }

    return (
        <header className='header'>
            <div className='container'>
                <div className='header__content__wrapper'>
                    <div className='header__logo__wrapper' onClick={() => navigate('/')}>
                        <div className='header__image__wrapper'>
                            <img className='header__logo' src={logo} alt="logo" />
                        </div>
                        <h2 className='header__text'>Нарушениям.нет</h2>
                    </div>
                    <nav className='header__navigation'>
                        <ul className='header__links__list'>
                            <li className='header__link__wrapper'>
                                <Link to='/' className='header__link'>Все заявки</Link>
                            </li>
                            {userToken === '' ? (
                                <>
                                    <li className='header__link__wrapper'>
                                        <Link to='/signup' className='header__link'>Регистрация</Link>
                                    </li>
                                    <li className='header__link__wrapper'>
                                        <Link to='/login' className='header__link'>Авторизация</Link>
                                    </li>
                                </>
                            ) : (
                                <>
                                    {isAdmin ? (
                                        <>
                                            <li className='header__link__wrapper'>
                                                <Link to='/admin' className='header__link'>Админ-панель</Link>
                                            </li>
                                        </>
                                    ) : (
                                        <>
                                            <li className='header__link__wrapper'>
                                                <Link to='/myapplications' className='header__link'>Мои заявки</Link>
                                            </li>
                                            <li className='header__link__wrapper'>
                                                <Link to='/application/create' className='header__link'>Подать заявку</Link>
                                            </li>
                                        </>
                                    )}
                                    <li className='header__link__wrapper'>
                                        <a href='#' onClick={logout} className='header__link'>Выйти</a>
                                    </li>
                                </>
                            )}
                        </ul>
                    </nav>
                </div>
            </div>
        </header>
    )
}