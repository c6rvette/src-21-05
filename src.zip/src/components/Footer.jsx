import '../assets/css/style.css'

export default function Footer() {
    return (
        <footer className='footer'>
            <div className='container'>
                <div className='footer__content__wrapper'>
                    <p className='footer__text'>Все права защищены</p>
                    <p className='footer__text'>by Badili</p>
                </div>
            </div>
        </footer>
    )
}