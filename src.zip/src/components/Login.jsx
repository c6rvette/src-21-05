import { useState } from 'react'
import '../assets/css/style.css'
import { useNavigate } from 'react-router-dom'

export default function Login({setUserToken, setIsAdmin}) {
    const [user_login, setUserLogin] = useState('')
    const [password, setPassword] = useState('')
    const [error, setError] = useState('')
    const navigate = useNavigate()

    function login(event) {
        event.preventDefault()

        fetch('http://127.0.0.1:8000/api-copp/login/', {
            method: 'POST',
            headers: {
                'Content-type': 'application/json',
            },
            body: JSON.stringify({
                user_login, password
            })
        })
        .then(data => data.json())
        .then(response => {
            if(response.data) {
                setUserToken(response.data.user_token)
                setIsAdmin(response.data.isAdmin)
                navigate('/')
            } else {
                setError(response.error.message)
            }
        })
    }

    return (
        <section className='registration'>
            <div className='container'>
                <div className='registration__content__wrapper'>
                    <form className='registration__form'>
                        <input value={user_login} onChange={(event) => setUserLogin(event.target.value)} className='registration__input' type="text" placeholder='Login'/>
                        <input value={password} onChange={(event) => setPassword(event.target.value)} className='registration__input' type="password" placeholder='Password'/>
                        <p className='error__text'>{error}</p>
                        <button className='registration__button' onClick={login}>Войти</button>
                    </form>
                    <div className='back__button__wrapper' onClick={() => navigate('/')}>
                        <button className='back__button'>Назад</button>
                    </div>
                </div>
            </div>
        </section>
    )
}