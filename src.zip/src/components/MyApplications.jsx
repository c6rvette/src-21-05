import { useEffect, useState } from 'react'
import '../assets/css/style.css'
import { useNavigate } from 'react-router-dom'

export default function MyApplications({userToken}) {
    const [applications, setApplications] = useState([])
    const [searchedApplications, setSearchedApplications] = useState([])
    const [searchText, setSearchText] = useState('')
    const [isSearch, setIsSearch] = useState('')
    const navigate = useNavigate()

    useEffect(() => {
        fetch('http://127.0.0.1:8000/api-copp/applications', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${userToken}`
            }
        })
        .then(data => data.json())
        .then(response => setApplications(response.data))
    }, [])

    function search() {
        setIsSearch(true)
        const applications_list = []
        applications.map(application => {
            if(application.auto_number.includes(searchText)) {
                console.log(application.auto_number.includes(searchText))
                applications_list.push(application)
            }
        })
        setSearchedApplications(applications_list)
    }

    function stopSearch() {
        setIsSearch(false)
        setSearchText('')
        setSearchedApplications([])
    }

    function deleteApplication(id, index) {
        fetch(`http://127.0.0.1:8000/api-copp/application/${id}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${userToken}`
            }
        })
        setApplications([...applications.slice(0, index), ...applications.slice(index + 1)])
    }

    const printSearchedApplications = searchedApplications.map(application => {
        return (
            <li key={application.id} className='application'>
                <h2 className='application__auto__number'>{application.auto_number}</h2>
                <p className='application__description'>
                    {application.description}
                </p>
                <p className='application__username'>{application.name}</p>
                <p className='application__username'>{application.fio}</p>
                <p className='application__status'>{application.status}</p>
            </li>
        )
    })

    const printApplications = applications.map((application, index) => {
        return (
            <li key={application.id} className='application'>
                <h2 className='application__auto__number'>{application.auto_number}</h2>
                <p className='application__description'>
                    {application.description}
                </p>
                <p className='application__username'>{application.name}</p>
                <p className='application__username'>{application.fio}</p>
                <p className='application__status'>{application.status}</p>
                <button onClick={() => deleteApplication(application.id, index)} className='delete__application__button'>Удалить</button>
            </li>
        )
    })
    return (
        <section className='applications'>
            <div className='container'>
                <div className='applications__content__wrapper'>
                    <div className='back__button__wrapper' onClick={() => navigate('/')}>
                        <button className='back__button'>Назад</button>
                    </div>
                    <div className='search__wrapper'>
                        <input type="text" onFocus={stopSearch} value={searchText} onChange={(event) => setSearchText(event.target.value)} className='registration__input' placeholder='Поиск номера'/>
                        <button onClick={search}  className='registration__button'>Поиск</button>
                    </div>
                    <ul className='applications__list'>
                        
                    {!isSearch ? printApplications :  printSearchedApplications}

                    </ul>
                </div>
            </div>
        </section>
    )
}