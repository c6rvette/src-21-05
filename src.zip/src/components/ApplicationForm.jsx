import { useState } from 'react'
import '../assets/css/style.css'
import { useNavigate } from 'react-router-dom'

export default function ApplicationForm({userToken}) {
    const [name, setName] = useState('')
    const [auto_number, setAutoNumber] = useState('')
    const [description, setDescription] = useState('')
    const [error, setError] = useState('')
    const navigate = useNavigate()

    function createApplication(event) {
        event.preventDefault()

        fetch('http://127.0.0.1:8000/api-copp/application/', {
            method: 'POST',
            headers: {
                'Content-type': 'application/json',
                'Authorization': `Bearer ${userToken}`
            },
            body: JSON.stringify({
                auto_number, description, name
            })
        })
        .then(data => data.json())
        .then(response => {
            if(response.data) {
                navigate('/myapplications')
            } else {
                setError(response.error.message)
            }
        })
    }

    return (
        <section className='registration'>
            <div className='container'>
                <div className='registration__content__wrapper'>
                    <form className='registration__form'>
                        <input value={auto_number} onChange={(event) => setAutoNumber(event.target.value)} className='registration__input' type="text" placeholder='Auto number'/>
                        <input value={name} onChange={(event) => setName(event.target.value)} className='registration__input' type="text" placeholder='Victim name'/>
                        <textarea value={description} onChange={(event) => setDescription(event.target.value)} placeholder='Description' className='textarea__form'></textarea>
                        <p className='error__text'>{error}</p>
                        <button className='registration__button' onClick={createApplication}>Подать заявку</button>
                    </form>
                    <div className='back__button__wrapper' onClick={() => navigate('/')}>
                        <button className='back__button'>Назад</button>
                    </div>
                </div>
            </div>
        </section>
    )
}