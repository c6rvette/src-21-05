import { useState } from "react";
import Header from "./components/Header";
import { Route, Routes } from "react-router-dom";
import Applications from "./components/Applications";
import ApplicationForm from "./components/ApplicationForm";
import AdminPanel from "./components/AdminPanel";
import MyApplications from "./components/MyApplications";
import Registration from "./components/Registration";
import Login from "./components/Login";
import Footer from "./components/Footer";

function App() {
  const [isAdmin, setIsAdmin] = useState(false)
  const [userToken, setUserToken] = useState('')

  return (
    <>
      <Header isAdmin={isAdmin} userToken={userToken} setUserToken={setUserToken} setIsAdmin={setIsAdmin} />
      <Routes>
        <Route path="/" element={<Applications />} />
        <Route path="/application/create" element={<ApplicationForm userToken={userToken} />} />
        <Route path="/admin" element={<AdminPanel userToken={userToken} />} />
        <Route path="/myapplications" element={<MyApplications userToken={userToken} />} />
        <Route path="/signup" element={<Registration setUserToken={setUserToken} setIsAdmin={setIsAdmin} />} />
        <Route path="/login" element={<Login setUserToken={setUserToken} setIsAdmin={setIsAdmin} />} />
      </Routes>
      <Footer />
    </>
  );
}

export default App;
